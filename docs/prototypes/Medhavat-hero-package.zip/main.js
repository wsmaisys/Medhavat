import * as THREE from "./vendor/three/three.module.js";
import { OrbitControls } from "./vendor/three/OrbitControls.js";
import { EffectComposer } from "./vendor/three/EffectComposer.js";
import { RenderPass } from "./vendor/three/RenderPass.js";
import { UnrealBloomPass } from "./vendor/three/UnrealBloomPass.js";
import { OutputPass } from "./vendor/three/OutputPass.js";

// =============================================================
// Renderer, scene, camera
// =============================================================

const canvas = document.getElementById("scene-canvas");
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setClearColor(0x020509, 1);
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 0.9;

const scene = new THREE.Scene();
scene.fog = new THREE.FogExp2(0x020509, 0.018);

const camera = new THREE.PerspectiveCamera(
  42,
  window.innerWidth / window.innerHeight,
  0.1,
  200,
);
camera.position.set(0, 0.6, 28);
camera.lookAt(0, 0, 0);

const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0, 0, 0);
controls.enableDamping = true;
controls.dampingFactor = 0.06;
controls.minDistance = 12;
controls.maxDistance = 42;
controls.saveState();
let returningToHome = false;
let interactionActive = false;
let returnStartedAt = 0;
const interactionPath = [];
function beginReturn() {
  if (returningToHome) return;
  interactionActive = false;
  interactionPath.push({
    position: camera.position.clone(),
    target: controls.target.clone(),
  });
  returnStartedAt = performance.now();
  returningToHome = true;
  controls.enabled = false;
}
controls.addEventListener("start", () => {
  returningToHome = false;
  interactionActive = true;
  interactionPath.length = 0;
  interactionPath.push({
    position: camera.position.clone(),
    target: controls.target.clone(),
  });
});
controls.addEventListener("end", beginReturn);
canvas.addEventListener("pointerup", beginReturn);
canvas.addEventListener("pointercancel", beginReturn);

const clock = new THREE.Clock();

// =============================================================
// Shared materials and geometry helpers
// =============================================================

const COLORS = {
  background: 0x020509,
  cyan: 0x4fe0ff,
  purple: 0xb266ff,
  blue: 0x5f9fd1,
  glass: 0x9fd8ff,
  darkGlass: 0x2a3a55,
  core: 0x789eaa,
};

const ROTATION_SPEEDS = {
  outerRing: 1.05,
  spikes: 0.66,
  tunnel: 1.5,
  streams: 2.7,
  dust: 0.45,
};

const CORE_PULSE_SPEED = 2.0;
const CORE_PULSE_AMOUNT = 0.08;
const GLOW_PULSE_AMOUNT = 0.15;

function makeIrregularShard(size) {
  const geometry = new THREE.TetrahedronGeometry(size, 0);
  const position = geometry.attributes.position;
  for (let i = 0; i < position.count; i++) {
    position.setXYZ(
      i,
      position.getX(i) + (Math.random() - 0.5) * size * 0.4,
      position.getY(i) + (Math.random() - 0.5) * size * 0.4,
      position.getZ(i) + (Math.random() - 0.5) * size * 0.4,
    );
  }
  geometry.computeVertexNormals();
  return geometry;
}

function makeGlowTexture() {
  const textureCanvas = document.createElement("canvas");
  textureCanvas.width = 128;
  textureCanvas.height = 128;
  const context = textureCanvas.getContext("2d");
  const gradient = context.createRadialGradient(64, 64, 0, 64, 64, 64);
  gradient.addColorStop(0, "rgba(220,238,246,1)");
  gradient.addColorStop(0.18, "rgba(175,220,238,0.72)");
  gradient.addColorStop(0.55, "rgba(80,180,255,0.24)");
  gradient.addColorStop(1, "rgba(0,0,0,0)");
  context.fillStyle = gradient;
  context.fillRect(0, 0, 128, 128);
  return new THREE.CanvasTexture(textureCanvas);
}

const glowTexture = makeGlowTexture();

function makeRibbonCurve({
  baseRadius,
  radiusAmp,
  radiusFreq,
  zAmp,
  zFreq,
  phase,
  seed,
  depth,
}) {
  const points = [];
  const segments = 96;
  for (let i = 0; i < segments; i++) {
    const t = i / segments;
    const angle = t * Math.PI * 2 + phase;
    const radius =
      baseRadius + Math.sin(t * radiusFreq * Math.PI * 2 + seed) * radiusAmp;
    const z = -depth + Math.sin(t * zFreq * Math.PI * 2 + seed * 1.7) * zAmp;
    points.push(
      new THREE.Vector3(Math.cos(angle) * radius, Math.sin(angle) * radius, z),
    );
  }
  return new THREE.CatmullRomCurve3(points, true, "catmullrom", 0.45);
}

function buildRibbonGroup(configs, streamColors) {
  const group = new THREE.Group();
  const shape = new THREE.Shape([
    new THREE.Vector2(-0.12, -0.035),
    new THREE.Vector2(0.12, -0.035),
    new THREE.Vector2(0.12, 0.035),
    new THREE.Vector2(-0.12, 0.035),
  ]);

  configs.forEach((config, index) => {
    const color = streamColors[index % streamColors.length];
    const mesh = new THREE.Mesh(
      new THREE.ExtrudeGeometry(shape, {
        steps: 140,
        bevelEnabled: false,
        extrudePath: makeRibbonCurve(config),
      }),
      new THREE.MeshPhongMaterial({
        color,
        emissive: color,
        emissiveIntensity: 0.16,
        shininess: 120,
        transparent: true,
        opacity: 0.72,
        side: THREE.DoubleSide,
        depthWrite: false,
      }),
    );
    group.add(mesh);
  });

  return group;
}

// =============================================================
// Reusable portal factory
// =============================================================

function createPortal({
  x,
  tunnelAxis,
  rotationDirection,
  ringColor,
  streamColors,
}) {
  const root = new THREE.Group();
  root.position.set(x, 0, 0);
  root.quaternion.setFromUnitVectors(
    new THREE.Vector3(0, 0, -1),
    tunnelAxis.clone().normalize(),
  );
  scene.add(root);

  const outerRibbons = buildRibbonGroup(
    Array.from({ length: 8 }, (_, index) => ({
      baseRadius: 4.7 + (index % 4) * 0.42,
      radiusAmp: 0.18 + (index % 3) * 0.08,
      radiusFreq: 1.5 + (index % 4) * 0.35,
      zAmp: 0.28 + (index % 3) * 0.08,
      zFreq: 1.2 + (index % 5) * 0.24,
      phase: index * 0.34,
      seed: index * 1.13,
      depth: 0.15 + (index % 3) * 0.18,
    })),
    streamColors,
  );
  const innerRibbons = buildRibbonGroup(
    Array.from({ length: 6 }, (_, index) => ({
      baseRadius: 2.6 + (index % 4) * 0.58,
      radiusAmp: 0.14 + (index % 2) * 0.08,
      radiusFreq: 1.8 + (index % 3) * 0.42,
      zAmp: 0.22 + (index % 3) * 0.07,
      zFreq: 1.4 + (index % 4) * 0.3,
      phase: 0.5 + index * 0.48,
      seed: 2.1 + index * 0.91,
      depth: 0.5 + (index % 3) * 0.2,
    })),
    streamColors,
  );
  const streams = new THREE.Group();
  const dust = new THREE.Group();
  root.add(outerRibbons, innerRibbons, streams, dust);

  // Fifteen local spiral ribbons; these never connect the two portals.
  for (let i = 0; i < 15; i++) {
    const points = [];
    const turns = 1.25 + i * 0.08;
    const phase = i * 0.42;
    for (let segment = 0; segment <= 80; segment++) {
      const t = segment / 80;
      const angle = phase + t * turns * Math.PI * 2;
      const radius = THREE.MathUtils.lerp(4.35 - (i % 8) * 0.16, 0.45, t);
      points.push(
        new THREE.Vector3(
          Math.cos(angle) * radius * (1 + (i % 3) * 0.025),
          Math.sin(angle) * radius * (1 - (i % 4) * 0.018),
          -t * (5.6 + (i % 6) * 0.12),
        ),
      );
    }
    const curve = new THREE.CatmullRomCurve3(points);
    const stream = new THREE.Mesh(
      new THREE.TubeGeometry(curve, 180, 0.038 + (i % 3) * 0.009, 7, false),
      new THREE.MeshBasicMaterial({
        color: streamColors[i % streamColors.length],
        transparent: true,
        opacity: 0.32,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      }),
    );
    streams.add(stream);
  }

  // Balanced rim halo plus a centered dust trail through the tunnel.
  const dustPositions = new Float32Array(1400 * 3);
  for (let i = 0; i < 1400; i++) {
    if (i < 980) {
      const angle = Math.random() * Math.PI * 2;
      const radius = 4.55 + (Math.random() - 0.5) * 1.15;
      dustPositions[i * 3] = Math.cos(angle) * radius;
      dustPositions[i * 3 + 1] = Math.sin(angle) * radius;
      dustPositions[i * 3 + 2] = (Math.random() - 0.5) * 1.6;
    } else {
      const depth = Math.random();
      const angle = Math.random() * Math.PI * 2;
      const radius = THREE.MathUtils.lerp(3.3, 0.55, depth);
      dustPositions[i * 3] =
        Math.cos(angle) * (radius + (Math.random() - 0.5) * 0.35);
      dustPositions[i * 3 + 1] =
        Math.sin(angle) * (radius + (Math.random() - 0.5) * 0.35);
      dustPositions[i * 3 + 2] = -depth * 6.2 + (Math.random() - 0.5) * 0.35;
    }
  }
  const dustGeometry = new THREE.BufferGeometry();
  dustGeometry.setAttribute(
    "position",
    new THREE.BufferAttribute(dustPositions, 3),
  );
  dust.add(
    new THREE.Points(
      dustGeometry,
      new THREE.PointsMaterial({
        color: COLORS.glass,
        size: 0.045,
        transparent: true,
        opacity: 0.7,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      }),
    ),
  );

  // Keep a diffuse glow source at the tail without a visible sphere.
  const glowSprite = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: glowTexture,
      color: COLORS.cyan,
      transparent: true,
      opacity: 0.18,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    }),
  );
  glowSprite.scale.setScalar(2.8);
  glowSprite.position.set(0, 0, -5.0);
  root.add(glowSprite);

  const coreLight = new THREE.PointLight(COLORS.cyan, 1.4, 18, 2);
  coreLight.position.set(0, 0, -5.0);
  root.add(coreLight);
  const cyanLight = new THREE.PointLight(COLORS.cyan, 0.7, 16);
  cyanLight.position.set(1.5, 2, 2);
  root.add(cyanLight);
  const purpleLight = new THREE.PointLight(COLORS.purple, 0.6, 16);
  purpleLight.position.set(-1.5, -2, 1.5);
  root.add(purpleLight);

  return {
    root,
    outerRibbons,
    innerRibbons,
    streams,
    dust,
    glowSprite,
    rotationDirection,
  };
}

// =============================================================
// Mirrored portal instances
// =============================================================

const leftPortal = createPortal({
  x: -10.5,
  tunnelAxis: new THREE.Vector3(-0.95, 0, -0.31),
  rotationDirection: 1,
  ringColor: COLORS.cyan,
  streamColors: [COLORS.cyan, COLORS.purple, COLORS.blue],
});
const rightPortal = createPortal({
  x: 10.5,
  tunnelAxis: new THREE.Vector3(0.95, 0, -0.31),
  rotationDirection: -1,
  ringColor: COLORS.cyan,
  streamColors: [COLORS.cyan, COLORS.purple, COLORS.blue],
});

const interPortalDustCount = 520;
const interPortalDustPositions = new Float32Array(interPortalDustCount * 3);
const interPortalDustOrigins = new Float32Array(interPortalDustCount * 3);
const interPortalDustSeeds = new Float32Array(interPortalDustCount);
for (let i = 0; i < interPortalDustCount; i++) {
  const originX = Math.random() * 16 - 8;
  const originY = (Math.random() - 0.5) * 4.4;
  const originZ = Math.random() * 4.2 - 1.6;
  interPortalDustOrigins[i * 3] = originX;
  interPortalDustOrigins[i * 3 + 1] = originY;
  interPortalDustOrigins[i * 3 + 2] = originZ;
  interPortalDustPositions[i * 3] = originX;
  interPortalDustPositions[i * 3 + 1] = originY;
  interPortalDustPositions[i * 3 + 2] = originZ;
  interPortalDustSeeds[i] = Math.random() * Math.PI * 2;
}
const interPortalDustGeometry = new THREE.BufferGeometry();
interPortalDustGeometry.setAttribute(
  "position",
  new THREE.BufferAttribute(interPortalDustPositions, 3),
);
const interPortalDust = new THREE.Points(
  interPortalDustGeometry,
  new THREE.PointsMaterial({
    color: COLORS.glass,
    size: 0.035,
    transparent: true,
    opacity: 0.42,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
  }),
);
scene.add(interPortalDust);

// =============================================================
// Post-processing and resize
// =============================================================

const composer = new EffectComposer(renderer);
composer.addPass(new RenderPass(scene, camera));
composer.addPass(
  new UnrealBloomPass(
    new THREE.Vector2(window.innerWidth, window.innerHeight),
    0.45,
    0.6,
    0.2,
  ),
);
composer.addPass(new OutputPass());

window.addEventListener("resize", () => {
  const width = window.innerWidth;
  const height = window.innerHeight;
  camera.aspect = width / height;
  camera.updateProjectionMatrix();
  renderer.setSize(width, height);
  composer.setSize(width, height);
});

// =============================================================
// Render loop: every portal owns its own animation state
// =============================================================

function animatePortal(portal, elapsed) {
  const direction = portal.rotationDirection;
  portal.outerRibbons.rotation.z =
    elapsed * ROTATION_SPEEDS.outerRing * direction;
  portal.innerRibbons.rotation.z =
    elapsed * ROTATION_SPEEDS.tunnel * -direction;
  portal.dust.rotation.z = elapsed * ROTATION_SPEEDS.dust * direction;
  portal.streams.rotation.z = elapsed * ROTATION_SPEEDS.streams * -direction;

  portal.glowSprite.scale.setScalar(
    2.8 * (1 + Math.sin(elapsed * CORE_PULSE_SPEED) * GLOW_PULSE_AMOUNT),
  );
  portal.glowSprite.material.opacity =
    0.14 + Math.sin(elapsed * CORE_PULSE_SPEED) * 0.03;
}

function animateInterPortalDust(elapsed) {
  const position = interPortalDustGeometry.attributes.position;
  for (let i = 0; i < interPortalDustCount; i++) {
    const x = ((interPortalDustOrigins[i * 3] + elapsed * 1.8 + 8) % 16) - 8;
    const y =
      interPortalDustOrigins[i * 3 + 1] +
      Math.sin(elapsed * 1.3 + interPortalDustSeeds[i]) * 0.3;
    const z =
      interPortalDustOrigins[i * 3 + 2] +
      Math.sin(elapsed * 0.7 + interPortalDustSeeds[i] + x * 0.35) * 0.6;
    position.setXYZ(i, x, y, z);
  }
  position.needsUpdate = true;
}

function renderLoop() {
  requestAnimationFrame(renderLoop);
  const elapsed = clock.getElapsedTime();
  animatePortal(leftPortal, elapsed);
  animatePortal(rightPortal, elapsed);
  animateInterPortalDust(elapsed);
  if (returningToHome) {
    const progress = Math.min((performance.now() - returnStartedAt) / 1100, 1);
    const easedProgress = progress * progress * (3 - 2 * progress);
    const pathPosition = (1 - easedProgress) * (interactionPath.length - 1);
    const upperIndex = Math.ceil(pathPosition);
    const lowerIndex = Math.floor(pathPosition);
    const segmentAmount = pathPosition - lowerIndex;
    const upper = interactionPath[upperIndex] || interactionPath[0];
    const lower = interactionPath[lowerIndex] || interactionPath[0];
    camera.position.lerpVectors(lower.position, upper.position, segmentAmount);
    controls.target.lerpVectors(lower.target, upper.target, segmentAmount);
    camera.lookAt(controls.target);
    if (progress >= 1) {
      controls.enabled = true;
      camera.position.copy(controls.position0);
      controls.target.copy(controls.target0);
      controls.update();
      interactionPath.length = 0;
      returningToHome = false;
    }
  } else {
    controls.update();
    if (interactionActive) {
      interactionPath.push({
        position: camera.position.clone(),
        target: controls.target.clone(),
      });
      if (interactionPath.length > 180) interactionPath.shift();
    }
  }
  composer.render();
}

renderLoop();

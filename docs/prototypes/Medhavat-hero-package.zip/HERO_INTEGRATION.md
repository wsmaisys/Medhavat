# Medhavat Hero Scene

This bundle contains the current two-portal Three.js hero scene for Medhavat.

## Quick preview

Serve the bundle over HTTP and open `index.html`:

```bash
npx serve . -l 8080
```

## Website integration

1. Copy `main.js` and `vendor/three/` into the website's static assets.
2. Add the canvas and hero copy where the hero section should render:

```html
<section class="medhavat-hero">
  <canvas id="scene-canvas"></canvas>
  <div class="hero-copy" aria-label="Medhavat introduction">
    <p class="hero-kicker">Medhavat</p>
    <h1 class="hero-title">
      Transforming Business Ambition into Intelligent Software.
    </h1>
    <p class="hero-subtitle">Intellectual Tech. Real Business Growth.</p>
  </div>
</section>
```

3. Copy the `.hero-copy`, `.hero-kicker`, `.hero-title`, `.hero-subtitle`, and keyframe styles from `index.html` into the website stylesheet.
4. Keep the import paths in `main.js` aligned with the copied `vendor/three/` directory.
5. Load the scene as an ES module:

```html
<script type="module" src="/assets/main.js"></script>
```

The canvas should fill the hero section, while `.hero-copy` should be positioned above it with `z-index: 1` and `pointer-events: none`. The scene includes the mirrored portal animation, ribbon volumes, local dust, the flowing inter-portal dust, responsive resize handling, and smooth reverse camera-path return after cursor interaction.
